import React, { Component } from 'react';

class Tutorial extends Component {
  render() {
    return (
        <div>
            <p> Hello Tutorial </p>
        </div>
    );
  }
}

export default Tutorial;
