import React, { Component } from 'react';

class NotFound extends Component {
  render() {
    return (
        <div>
            <p> 404 Not Found </p>
        </div>
    );
  }
}

export default NotFound;
