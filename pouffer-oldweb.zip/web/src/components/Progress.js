import React, { Component } from 'react';

class Progress extends Component {
  render() {
    return (
        <div>
            <p> Hello Progress </p>
        </div>
    );
  }
}

export default Progress;
