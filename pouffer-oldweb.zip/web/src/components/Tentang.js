import React, { Component } from 'react';

class Tentang extends Component {
  render() {
    return (
        <div>
            <p> Hello Tentang </p>
        </div>
    );
  }
}

export default Tentang;
