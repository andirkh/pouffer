import React, { Component } from 'react';

class Dokumentasi extends Component {
  render() {
    return (
        <div>
            <p> Hello Dokumentasi </p>
        </div>
    );
  }
}

export default Dokumentasi;
