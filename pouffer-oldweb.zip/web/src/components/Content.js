import React, { Component } from 'react';

class Content extends Component {
  render() {
    return (
        <div>
            <p> Hello Content </p>
        </div>
    );
  }
}

export default Content;
