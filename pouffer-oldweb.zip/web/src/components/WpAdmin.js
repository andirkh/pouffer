import React, { Component } from 'react';

class WpAdmin extends Component {
  render() {
    return (
        <div>
            <p> HAHAHAHAHAHAHAHAHAHAHAHAHA </p>
        </div>
    );
  }
}

export default WpAdmin;
